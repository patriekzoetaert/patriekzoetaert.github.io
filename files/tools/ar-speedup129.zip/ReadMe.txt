ADOBE READER SPEED-UP V1.29
===========================
  Author  : Joseph Cox
  Website : http://www.tnk-bootblock.co.uk
  Forum   : http://www.tnk-bootblock.co.uk/forum
  Released: 23rd September, 2004.

CONTENTS
--------
Contents          - List of sections in this help file.
Preface           - A few introductory notes
Supports          - List of supported Adobe and Acrobat Readers
Purpose           - What this software is for
Settings Profiles - Maintain multiple installations of ARSU
Silent Deployment - Run ARSU quickly and silently
Upgrading Reader  - Upgrading to new versions of Adobe/Acrobat Reader
Upgrading ARSU    - Upgrading to new versions of ARSU
Removing ARSU     - How to "uninstall" Adobe Reader Speed-Up
Trouble-Shooting  - Fixing common problems
History           - Release history of ARSU

NOTICE: Even though this release partially supports Reader 7.0 Beta,
it is not recommended that you install 7.0 just to test with ARSU.
Adobe Reader 7.0 Beta seems to do "something" with previous installations
of Reader that cause it to break and consequently confuses ARSU.


PREFACE
-------
Thanks to everyone that has donated so far; you don't
truly know how much it helps - thanks again!

Notice: Since v1.20, ARSU stores unused plugins in the
Optional folder of Acrobat/Reader. This means that
when a PDF is viewed and Acrobat/Reader requires a
plugin for full functionality, it'll be loaded for
that particular PDF only.

Important: If you used v1.16 or lower and immediately
upgraded to this version, then you absolutely have to
perform a Restore Original Configuration using v1.16
before using this version. If you don't, then you will
certainly run in to Speed-Up/Restore problems.

If you need v1.16, download it from here:
  http://www.tnk-bootblock.co.uk/getfile.php?id=arsu116
  

Restore using v1.16 or lower, then use this version
and do a Speed-Up. This is absolutely essential.

SUPPORTS
--------
This software supports the speed-up of the following:
(Note: CE, free, and full versions are supported)

  Adobe Acrobat 3.0
  Adobe Acrobat 4.0
  Adobe Acrobat 4.0.5
  Adobe Acrobat 5.0
  Adobe Acrobat 5.1
  Adobe Acrobat 5.5
  Adobe Acrobat/Reader  6.0
  Adobe Acrobat/Reader  6.0.1
  Adobe Acrobat/Reader  6.0.2
  Adobe Acrobat/Reader  7.0.0 Beta (Adobe - you're idiots!*)

In other words, any version of the Acrobat/Reader software
from 3.0 and upwards should be supported.

* Sorry Adobe, but I can't believe how stupid a company can
  be. You're now *forcing* plugins to stay resident in the
  plug_ins directory? Decided to install a Windows service
  or something equally idiotic for this little gem, did we?


PURPOSE
-------
Adobe Reader Speed-Up (ARSU) was created in an effort to automate
the process of speeding up Adobe Reader's launch time by
disabling the majority of plugins that are, quite franky,
completely useless for most users.

If the program gives you an error when you try to run it,
then you require the VB Runtimes pack. Download it here:
  http://www.tnk-bootblock.co.uk/?id=vbruntimes

When the program is up and running, select your Adobe
Reader directory if you are prompted to via the Change Settings
link on the first step, then click Next and select the
type of speed up you require ("SpeedUp - Fast" is recommended),
and finally click on the Start button.

If you should require to revert back to the original slow
loading state, then run the program again and select Restore
Original Configuration and click on Start.

For information on what the plugins do, click on the Plugin
Help button in the step with the list of plugins. Then click
on a plugin to display its respective information.

That's all there is to it.


SETTINGS PROFILES
-----------------
ARSU saves its settings using the current path of the program
executable. This means that you can have an ARSU executable in
C:\, and another one in C:\MyDir, and both of them would maintain
completely independent settings. This is useful if you have more
than one Adobe Reader/Acrobat installation and would like to quickly
and easily modify them without having to continually re-select
the install path using the Settings window.


SILENT DEPLOYMENT
-----------------
ARSU can be deployed silently. To enable this mode, load the
Deployment.ini file into a text editor and set the Enable flag to
1. This should be enough for most configurations. For more
options, see the inline comments within the Deployment.ini
file itself.


UPGRADING READER
----------------
It is recommended that you do a Restore Configuration before
applying an update from Adobe for Acrobat/Reader.


UPGRADING ARSU
--------------
To upgrade to a new version of Adobe Reader Speed-Up, simply
delete the directory containing the previous version of ARSU,
and extract/copy the new version to its location.

Alternatively, you can extract the new version directly over
the old version.


REMOVING ARSU
-------------
To remove Adobe Reader Speed-Up from your system, simply quit
the application and delete its directory.


TROUBLE-SHOOTING
----------------
If you get an error when you start ARSU (about a file missing
or whatever), then you will need to download the VB Runtimes pack:
  http://www.tnk-bootblock.co.uk/?id=vbruntimes

If Adobe Acrobat/Reader gives you any errors after you run ARSU,
then do a Restore Configuration, activate Plugin Help and make
sure that you aren't disabling any plugins that depend on other
plugins to work. This is not a bug of ARSU, but how Adobe
Reader/Acrobat was designed to work.

Finally, PluginHelp.txt contains information on the Adobe
plugins, and is used by Adobe Reader Speed-Up. You should
not view this file yourself as it is in a user-unfriendly
format. Click on the Plugin Help button within ARSU to view
it in a more presentable format.

Joseph Cox
(AKA BootBlock)



HISTORY
-------
v1.29 - 23rd September, 2004.
  - Added: It's now possible to change the System and Common
           directories that ARSU uses for some of its tweaks.
  - Added: Link to Reader in the Settings window.
  - Added: Preliminary support for Adobe Reader 7.0 Beta (sigh..).
  - Other: Minor changes here and there.
  - Other: Updates to the manual.

v1.28 - 5th August, 2004.
  - Fixed: Silent Deployment broke in v1.27. Now fixed.
  - Other: Backup Location must now reside on the same
           drive as the Acrobat application.

v1.27 - 29th July, 2004.
  - Fixed: Another attempt to fix Speed-Up failures.
           Seems to have worked, at least partially anyway.

v1.26 - 29th July, 2004.
  - Fixed: Attempted to fix speed-Up failures.

v1.25 - 29th July, 2004.
  - Added: New tweaks to the Tweaks section.
  - Fixed: Speed-Up failures some users were experiencing.
  - Other: Redesigned Tweaks section.
  - Other: Various minor changes and improvements.

v1.21 - 28th April, 2004.
  - Added: URL to download v1.16 in ReadMe.txt.
  - Fixed: A Speed-Up wouldn't work after doing a Restore using
           a previous version of ARSU.

v1.20 - 27th April, 2004.
  - Notice: If you have used a previous version of ARSU, then
            perform a Restore before using this version otherwise
            you will run in to problems. This is essential.
  - Added: Fix Reader Startup Problems to Tweaks.
  - Other: ARSU now backs up plugins using the Optional folder.
           This means that Reader loads plugins on demand and
           consequently you'll never need to do a Restore
           Configuration ever again.
  - Other: Works again in Win98 and doesn't require any
           dependencies to be installed under WinXP or higher.

v1.16 - 28th March, 2004.
  - Added: Reset Speed-Up status to Tweaks section.

v1.15 - 25th January, 2004; Birthday Release!
  - Added: Support for all CE versions of Acrobat/Reader.
  - Added: Extended error checking and information messages.
  - Added: WorldReady.api to the profiles (for CE versions).
  - Added: About window. Includes donation information.
  - Fixed: Potentially serious bug preventing ARSU from working
           properly with non-English versions of Acrobat/Reader.
  - Other: Now fully supports Windows XP theming.

v1.14 - 19th January, 2004.
  - Added: Tweaks section.
  - Added: Support for Adobe Acrobat 5.0 CE.
  - Added: Added 27 new plugin descriptions.
           Thanks to Sebasti�n Naccas.

v1.13 - 16th January, 2004.
  - Added: More coach messages on potential error situations.
  - Added: Plugin Info.pdf courtesy of Nat Taylor.
  - Fixed: Plugin dependency information wasn't being loaded.
           Thanks to Baja Joe for reporting.
  - Fixed: Occasional text flickering in Windows XP.
  - Other: Very minor changes.

v1.12 - 1st January, 2004.
  - Added support for Adobe Acrobat Reader 4.0 and 5.5.
  - Added experimental support for Adobe Acrobat 3.
  - Added silent deployment support. See ReadMe.txt.
  - Added more plugin descriptions to Plugin Help. (thanks to Philco)
  - Plugin Help can be edited by editing PluginHelp.txt.
  - Improved checking for Acrobat/Reader installations.
  - Improved error checking and handling.
  - Fixed bug that could result in the Speed Up operation failing.

v1.11 - 27th December, 2003.
  - ARSU can now maintain more than one settings profile.
    See Settings Profiles in ReadMe.txt for more information.
  - If there are multiple installations of Adobe Reader, then
    the latest installed version will be used as default.
  - Added more plugin descriptions to Plugin Help.
  - Minor changes.

v1.10 - 24th December, 2003.
  - Greatly improved checking for existing Acrobat/Reader
    installations.
  - Two Speed-Ups now cannot be performed in a row. You
    need to do a Restore before you can Speed-Up again.
    Same applies to doing two Restores in a row.
  - Plugin details now work on non-English versions of
    Reader.
  - Fixed tooltips.

v1.09 - 21st December, 2003.
  - Redesigned interface.
  - Now supports the non-free version of Reader 6.
  - Backup location can now be changed.
  - Changed Fast/Turbo plugin selection profiles,
    as recommended by Jonathan Topping.

v1.00 - 16th September, 2003.
  - Initial release.
