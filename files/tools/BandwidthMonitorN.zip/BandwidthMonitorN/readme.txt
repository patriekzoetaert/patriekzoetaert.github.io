Emsa Bandwidth Monitor - Readme.txt
---------------------------------

Important Installation Notes: 
----------------------------
This product requires the VB6 Runtime, which should be downloaded from Microsoft at:
http://download.microsoft.com/download/vb60pro/Redist/sp5/WIN98Me/EN-US/vbrun60sp5.exe (1 MB)

Please install the runtime before running the program. In some cases you may be prompted to reboot once
after installing the runtime.
[ Some systems may not need the runtime or have it already installed. If you get any errors when starting
the program, the missing runtime is likely to be the cause. ]

WinXP and above, users: Good news - The program may run on XP and above without the need to install the vb
runtime because it usually comes with the operating system.
------------------------------------

Emsa Bandwidth Monitor - Net speed measurement utility for Windows 98/ME/NT/XP/2000/2003 
---------------------------------------------------------------------------------
This program is FREEWARE. Please refer to the license.txt file for more information.

Emsa Bandwidth Monitor is program that allows monitoring your internet connection speed, total traffic, average download/upload speed, etc. It is very simple to use; runs as system tray icon and shows a small, transparent-able, repositionable window that you can place on your desktop. It also allow viewing extended Net adapter interface settings, like MAC address, speed, etc. It allows viewing traffic data per interface or as a whole. It can be set to autorun at system startup. This program has been designed with simplicity in mind, but usefulness for the user.

Installation
------------
No Installation is required. Simply unzip the files, and run the main executable. Please read the included 
text files before actually running the executable.

To configure the program to autorun at startup, double click(run) the InstallAutorun.bat file. To remove autorun, double-click the UninstallAutorun.bat file.

If you have suggestions, bugs spotted, requests for new features, please email us. Thanks!

System requirements
-------------------
Any usual Windows machine with one mbyte of disk space will do. 800x600 min screen resolution.

Support and feedback
--------------------
Please refer to the license.txt file for information about support and feedback.
Email: support@e-systems.ro

License Information
-------------------
Please read the license.txt for licensing information.

====================
Emsa Bandwidth Monitor (c) 2004 EMSA Systems Ltd.
Web site : http://www.e-systems.ro/
